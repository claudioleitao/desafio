package br.com.flexpag.postomedicoveterinario.excessao;

public class EncontradoException extends Exception {

	public EncontradoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
