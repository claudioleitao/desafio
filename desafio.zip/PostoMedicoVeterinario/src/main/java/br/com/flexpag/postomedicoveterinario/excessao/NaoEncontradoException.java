package br.com.flexpag.postomedicoveterinario.excessao;

public class NaoEncontradoException extends Exception{

	public NaoEncontradoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
