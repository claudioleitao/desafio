package br.com.flexpag.postomedicoveterinario.excessao;

public class CamposEmBrancoException extends Exception {

	public CamposEmBrancoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
