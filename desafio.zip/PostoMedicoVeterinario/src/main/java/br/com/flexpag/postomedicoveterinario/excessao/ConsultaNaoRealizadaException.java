package br.com.flexpag.postomedicoveterinario.excessao;

public class ConsultaNaoRealizadaException extends Exception {

	public ConsultaNaoRealizadaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
